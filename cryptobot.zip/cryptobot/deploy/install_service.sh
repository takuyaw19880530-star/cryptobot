#!/bin/bash
# systemdサービスとcronを自動登録する(観測モード開始用)
set -e
DIR=/root/cryptobot

cat > /etc/systemd/system/cryptobot.service <<EOF
[Unit]
Description=Crypto trading bot (executor)
After=network-online.target

[Service]
Type=simple
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python main.py run
Restart=always
RestartSec=30

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now cryptobot

( crontab -l 2>/dev/null | grep -v cryptobot ;
  echo "0 7 * * *  cd $DIR && venv/bin/python main.py morning >> data/cron.log 2>&1" ;
  echo "5 0 * * *  cd $DIR && venv/bin/python main.py journal >> data/cron.log 2>&1" ;
  echo "0 8 * * 1  cd $DIR && venv/bin/python main.py review  >> data/cron.log 2>&1" ) | crontab -

echo "═══ 常駐化完了 ═══"
systemctl status cryptobot --no-pager | head -5
echo "cron登録済み: 毎日7:00作戦会議 / 0:05日誌 / 月曜8:00反省会"
echo "停止したい場合: systemctl stop cryptobot"
