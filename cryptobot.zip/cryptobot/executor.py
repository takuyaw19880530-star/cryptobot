# -*- coding: utf-8 -*-
"""
執行エンジン(常時稼働ループ)— BTC/JPY現物版
==============================================
- 朝の作戦(plans)のレジームに応じてstrategy.pyのシグナルを執行(買いのみ)
- DRY_RUN=True の間は発注せず、仮想約定としてSQLiteに記録
- 1エントリー = ORDER_JPY円分のBTC(最小0.001BTC)。レバレッジなし
- ポジション保有中は15秒間隔でSL/TP監視
"""
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import config
import db
import notify
import risk
import strategy
from bitflyer_client import BitflyerClient

JST = ZoneInfo("Asia/Tokyo")


def calc_size(price: float) -> float | None:
    """円建て投入額からBTC数量を計算。最小ロットが高すぎる場合はNone"""
    min_value = config.MIN_BTC_SIZE * price
    if min_value > config.MAX_ORDER_JPY:
        return None  # 最小ロットでも投入上限を超える → 見送り
    size = max(config.ORDER_JPY / price, config.MIN_BTC_SIZE)
    return round(size, config.SIZE_DECIMALS)


def open_position(bf: BitflyerClient, sig: dict, regime: str):
    size = calc_size(sig["entry"])
    if size is None:
        notify.send("⚠️ 最小ロット価値が投入上限を超えるため見送り")
        return
    pos = {
        "date": db.today_jst(),
        "ts_open": datetime.now(JST).isoformat(timespec="seconds"),
        "side": "BUY", "size": size,
        "entry": sig["entry"], "sl": sig["sl"], "tp": sig["tp"],
        "regime": regime, "reason_open": sig["reason"],
        "dry_run": config.DRY_RUN,
    }
    if not config.DRY_RUN:
        bf.market_buy(config.PRODUCT_CODE, size)
        time.sleep(2)
        # 実約定価格の厳密な取得は約定履歴照会で行う(フェーズ2で実装確認)
    db.save_position(pos)
    tag = "🧪DRY" if config.DRY_RUN else "💴実弾"
    notify.send(f"{tag} **新規 BUY** {size}BTC (約{size*sig['entry']:,.0f}円) "
                f"@{sig['entry']:,.0f}\nSL {pos['sl']:,.0f} / TP {pos['tp']:,.0f}\n"
                f"{pos['reason_open']}")


def close_position(bf: BitflyerClient, pos: dict, exit_price: float,
                   reason: str):
    if not config.DRY_RUN:
        bf.market_sell(config.PRODUCT_CODE, pos["size"])
    pct, jpy = strategy.pl_of(pos, exit_price)
    trade = dict(pos)
    trade.update({"ts_close": datetime.now(JST).isoformat(timespec="seconds"),
                  "exit": exit_price, "pl_pips": pct, "pl_jpy": jpy,
                  "reason_close": reason})
    db.record_trade(trade)
    db.save_position(None)
    emoji = "✅" if jpy >= 0 else "🔻"
    notify.send(f"{emoji} **決済 SELL** @{exit_price:,.0f} "
                f"({pct:+.2f}% / {jpy:+.0f}円)\n{reason}\n"
                f"本日累計: {db.daily_pl(db.today_jst()):+.0f}円")


def loop():
    bf = BitflyerClient()
    notify.send(f"🤖 cryptobot起動 (DRY_RUN={config.DRY_RUN})")
    while True:
        try:
            pos = db.load_position()
            now = datetime.now(JST)

            # メンテナンス帯は監視も休む(保有中でも約定できないため)
            if risk.in_maintenance(now):
                time.sleep(120)
                continue

            # 取引所の稼働状態が異常なら待機
            if bf.health(config.PRODUCT_CODE) == "STOP":
                notify.send("⚠️ 取引所STOP状態。5分待機")
                time.sleep(300)
                continue

            if pos:
                ex = strategy.check_exit(pos, bf)
                if ex:
                    close_position(bf, pos, ex["exit"], ex["reason"])
                time.sleep(config.POLL_IN_POS_SEC)
            else:
                ok, why = risk.can_open_new(now)
                plan = db.load_plan()
                if ok and plan and plan.get("regime") in ("trend_up", "range") \
                        and not risk.in_caution_window(plan, now):
                    sig = strategy.check_entry(plan, bf)
                    if sig:
                        open_position(bf, sig, plan["regime"])
                time.sleep(config.POLL_FLAT_SEC)

        except KeyboardInterrupt:
            notify.send("🛑 cryptobot手動停止")
            break
        except Exception as e:
            notify.send(f"⚠️ cryptobotエラー: {e} (60秒後に再開)")
            time.sleep(60)


if __name__ == "__main__":
    loop()
