# cryptobot — Claude判断ハイブリッドBTC/JPY現物自動売買bot

10万円を「絶対に破産しない設計」で運用するBTC/JPY現物(レバレッジなし)bot。
毎朝Claudeがweb検索込みでレジームを判定し、日中は純ルールの執行エンジンが
機械的に売買(買いのみ)。夜はClaudeが日誌、月曜朝に週次反省会(提案のみ)。

## アーキテクチャの要点

- **発注: bitFlyer** / **チャートデータ: bitbank Public API(口座不要)**
  ※bitFlyer公式APIにはローソク足エンドポイントがないための2系統構成
- **現物ロングオンリー**: 空売りしない。trend_down判定の日は見送り。
  最大損失は投入額に構造的に限定される
- **%ベースのSL/TP**(暫定 SL1.2%/TP1.8%)。1エントリー2万円分
  → 1トレード最大損失 約240円
- 戦略はライブとバックテストが同一の純粋関数を共有(ロジック乖離なし)

## リスクルール(config.pyに固定)

- 日次 -2,000円で当日停止 / 週次 -5,000円で全停止(手動解除まで)
- ポジション常に1つ、bitFlyerメンテ帯(3:55-4:15 JST)は停止
- APIキーに入出金権限を付けない

## セットアップ(VPS: Ubuntu想定)

```bash
sudo timedatectl set-timezone Asia/Tokyo
sudo apt update && sudo apt install -y python3-venv git
git clone <このリポジトリ> cryptobot && cd cryptobot
python3 -m venv venv && venv/bin/pip install -r requirements.txt
cp .env.example .env && nano .env   # APIキー3種を設定

venv/bin/python main.py status          # 動作確認
venv/bin/python main.py backtest 90     # バックテスト(口座不要!)
venv/bin/python main.py morning         # 作戦会議を手動テスト

sudo cp deploy/cryptobot.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now cryptobot
crontab -e   # deploy/crontab.example を貼る(毎日7:00/0:05、月曜8:00)
```

## 運用フェーズ

1. **フェーズ0.5: バックテスト(今すぐ・口座不要)** — bitbankの実データで
   `main.py backtest 90`。%パラメータの妥当性をここで再調整する
2. **フェーズ1: 観測モード(2〜4週間)** — `DRY_RUN=True`(初期値)で
   発注ゼロ運用。日誌と反省会で期待値を確認。**勝てそうにないなら進まない**
3. **フェーズ2: 最小サイズ実弾** — bitFlyer審査完了後、APIキー発行
   (入出金権限なし)、`DRY_RUN=False`。移行前に必ず: 最小注文数量
   (BTC_JPY 0.001)とメンテ時間帯を公式で確認し、`bitflyer_client.py`の
   発注系2関数を公式ドキュメントと突き合わせて手動テスト1回
4. **フェーズ3: 通常運用** — 週次反省会の提案を吟味しながら継続

## 既知の限界(正直に)

- レジーム判定の過去再現は不可(バックテストは代理判定)
- bitbank(データ)とbitFlyer(約定)の価格には僅かな差がある
- BTCの急変(数分で数%)ではSLが滑る。%パラメータは暫定値であり、
  バックテストでの再調整が前提
- このbotは利益を保証しない。暗号資産は元本を失うリスクがある
