# -*- coding: utf-8 -*-
"""テクニカル指標。pandasに依存せず純Pythonで実装(VPSを軽く保つ)"""


def ema(values: list[float], period: int) -> list[float]:
    if len(values) < period:
        return []
    k = 2 / (period + 1)
    out = [sum(values[:period]) / period]
    for v in values[period:]:
        out.append(v * k + out[-1] * (1 - k))
    return out


def rsi(closes: list[float], period: int = 14) -> float | None:
    if len(closes) < period + 1:
        return None
    gains, losses = [], []
    for i in range(1, len(closes)):
        d = closes[i] - closes[i - 1]
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    avg_g = sum(gains[:period]) / period
    avg_l = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_g = (avg_g * (period - 1) + gains[i]) / period
        avg_l = (avg_l * (period - 1) + losses[i]) / period
    if avg_l == 0:
        return 100.0
    return 100 - 100 / (1 + avg_g / avg_l)


def atr(klines: list[dict], period: int = 14) -> float | None:
    if len(klines) < period + 1:
        return None
    trs = []
    for i in range(1, len(klines)):
        h, l = klines[i]["high"], klines[i]["low"]
        pc = klines[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    val = sum(trs[:period]) / period
    for tr in trs[period:]:
        val = (val * (period - 1) + tr) / period
    return val


def bollinger(closes: list[float], period: int = 20, num_std: float = 2.0):
    if len(closes) < period:
        return None
    window = closes[-period:]
    mid = sum(window) / period
    var = sum((c - mid) ** 2 for c in window) / period
    std = var ** 0.5
    return {"mid": mid, "upper": mid + num_std * std,
            "lower": mid - num_std * std, "std": std}


def summarize_market(klines_15m: list[dict], klines_1h: list[dict]) -> dict:
    """朝の作戦会議でClaudeに渡す市場サマリーを作る"""
    closes_15 = [k["close"] for k in klines_15m]
    closes_1h = [k["close"] for k in klines_1h]
    ema20 = ema(closes_15, 20)
    ema50 = ema(closes_15, 50)
    bb = bollinger(closes_15)
    return {
        "last_price": closes_15[-1] if closes_15 else None,
        "rsi_15m": round(rsi(closes_15) or 0, 1),
        "atr_15m_pips": round((atr(klines_15m) or 0) * 100, 1),
        "ema20_vs_ema50_15m": ("ema20>ema50" if ema20 and ema50 and
                               ema20[-1] > ema50[-1] else "ema20<=ema50"),
        "bb_width_pips": round((bb["upper"] - bb["lower"]) * 100, 1) if bb else None,
        "range_24h": {
            "high": max(k["high"] for k in klines_1h[-24:]) if len(klines_1h) >= 24 else None,
            "low": min(k["low"] for k in klines_1h[-24:]) if len(klines_1h) >= 24 else None,
        },
        "recent_1h_closes": [round(c, 3) for c in closes_1h[-12:]],
    }
