# -*- coding: utf-8 -*-
"""
bitFlyer Lightning APIクライアント(現物)
=========================================
公式ドキュメント: https://lightning.bitflyer.com/docs

認証(公式準拠):
  ACCESS-SIGN = HMAC-SHA256(timestamp + method + path + body)
  ※ GETでクエリパラメータがある場合、pathにはクエリ文字列を含める
    (GMOコインとは逆の仕様なので注意)

注意: 発注系メソッドは実弾移行前に必ず公式ドキュメントと突き合わせ、
最小注文数量(BTC_JPY: 0.001 BTC)も /v1/markets 等で確認すること。
観測モード(DRY_RUN=True)では発注系は一切呼ばれない。
"""
import hashlib
import hmac
import json
import os
import time

import requests

BASE_URL = "https://api.bitflyer.com"


class BitflyerClient:
    def __init__(self):
        self.api_key = os.environ.get("BITFLYER_API_KEY", "")
        self.api_secret = os.environ.get("BITFLYER_API_SECRET", "")
        self._last_post = 0.0

    # ── Public ──────────────────────────────────────────

    def ticker(self, product_code: str) -> dict:
        """{'ask','bid','mid','ltp'} を返す"""
        r = requests.get(f"{BASE_URL}/v1/ticker",
                         params={"product_code": product_code}, timeout=10)
        r.raise_for_status()
        d = r.json()
        ask, bid = float(d["best_ask"]), float(d["best_bid"])
        return {"ask": ask, "bid": bid, "mid": (ask + bid) / 2,
                "ltp": float(d["ltp"])}

    def health(self, product_code: str) -> str:
        """取引所の稼働状態: NORMAL / BUSY / VERY BUSY / SUPER BUSY / STOP"""
        r = requests.get(f"{BASE_URL}/v1/gethealth",
                         params={"product_code": product_code}, timeout=10)
        r.raise_for_status()
        return r.json().get("status", "UNKNOWN")

    # ── Private ─────────────────────────────────────────

    def _request(self, method: str, path: str, body: dict | None = None):
        ts = str(time.time())
        body_str = json.dumps(body) if body else ""
        text = ts + method + path + body_str
        sign = hmac.new(self.api_secret.encode(), text.encode(),
                        hashlib.sha256).hexdigest()
        headers = {"ACCESS-KEY": self.api_key, "ACCESS-TIMESTAMP": ts,
                   "ACCESS-SIGN": sign, "Content-Type": "application/json"}
        if method == "POST":
            wait = 1.1 - (time.time() - self._last_post)
            if wait > 0:
                time.sleep(wait)
            r = requests.post(BASE_URL + path, data=body_str,
                              headers=headers, timeout=10)
            self._last_post = time.time()
        else:
            r = requests.get(BASE_URL + path, headers=headers, timeout=10)
        r.raise_for_status()
        return r.json() if r.text else {}

    def balance(self) -> dict:
        """通貨コード→残高。例: {'JPY': 100000.0, 'BTC': 0.0012}"""
        data = self._request("GET", "/v1/me/getbalance")
        return {d["currency_code"]: float(d["amount"]) for d in data}

    def market_buy(self, product_code: str, size: float) -> dict:
        """成行買い(現物)。sizeはBTC数量"""
        return self._request("POST", "/v1/me/sendchildorder", {
            "product_code": product_code, "child_order_type": "MARKET",
            "side": "BUY", "size": size})

    def market_sell(self, product_code: str, size: float) -> dict:
        """成行売り(保有現物の決済)"""
        return self._request("POST", "/v1/me/sendchildorder", {
            "product_code": product_code, "child_order_type": "MARKET",
            "side": "SELL", "size": size})
