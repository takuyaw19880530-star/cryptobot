# -*- coding: utf-8 -*-
"""
cryptobot 設定ファイル(BTC/JPY 現物・ロングオンリー)
=====================================================
方針: レバレッジなしの現物のみ。最大損失は投入額に構造的に限定される。
週次反省会の提案が出ても、ここを人間が書き換えない限り何も変わらない。
"""

# ── 動作モード ──────────────────────────────────────────
DRY_RUN = True   # Trueの間は一切発注しない(観測モード)。最低2〜4週間維持

# ── 取引対象 ────────────────────────────────────────────
PRODUCT_CODE = "BTC_JPY"       # bitFlyer(発注)
BITBANK_PAIR = "btc_jpy"       # bitbank(チャートデータ)
ORDER_JPY = 20000              # 1エントリーの投入額(円)
MAX_ORDER_JPY = 30000          # 最小ロット価値がこれを超える場合は見送り
MIN_BTC_SIZE = 0.001           # bitFlyerの最小注文数量(実弾前に要確認)
SIZE_DECIMALS = 8              # BTC数量の丸め桁

# ── リスク管理 ──────────────────────────────────────────
# 1トレード最大損失 ≒ ORDER_JPY × SL_PCT ≒ 240円
DAILY_LOSS_LIMIT_JPY = -2000   # 日次でこれに達したら当日停止
WEEKLY_LOSS_LIMIT_JPY = -5000  # 週次で全停止(手動解除まで再開しない)
MAX_POSITIONS = 1              # 同時ポジションは常に1つまで

# ── 戦略パラメータ(%ベース、週次反省会の見直し対象) ────
# 暫定値。実データのバックテストで必ず再調整すること
TREND_SL_PCT = 1.2    # トレンド日の損切り幅(%)
TREND_TP_PCT = 1.8    # トレンド日の利確幅(%) RR 1.5
RANGE_SL_PCT = 1.0    # レンジ日の損切り幅(%)
RANGE_TP_PCT = 1.4    # レンジ日の利確幅(%)
RSI_OVERSOLD = 30
EMA_NEAR_PCT = 0.15   # 「EMA20近傍」判定の幅(%)
LONG_ONLY = True      # 現物のため買いのみ。trend_downの日は見送り

# ── 取引時間 (JST) ──────────────────────────────────────
# 暗号資産は24時間365日。ただしbitFlyerの日次メンテナンス帯は停止
MAINTENANCE_START = "03:55"    # 余裕をもって前後5分広げてある
MAINTENANCE_END = "04:15"      # (公式メンテは4:00-4:10、実弾前に要確認)

# ── ループ間隔(秒) ────────────────────────────────────
POLL_FLAT_SEC = 60
POLL_IN_POS_SEC = 15

# ── Claude API ──────────────────────────────────────────
CLAUDE_MODEL = "claude-sonnet-4-6"
MORNING_MAX_TOKENS = 2000
JOURNAL_MAX_TOKENS = 2000
REVIEW_MAX_TOKENS = 3000

# ── ファイルパス ────────────────────────────────────────
DB_PATH = "data/cryptobot.db"
JOURNAL_DIR = "journal"
HALT_FLAG = "data/HALTED"
