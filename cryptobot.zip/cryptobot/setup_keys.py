# -*- coding: utf-8 -*-
"""
APIキーの対話式セットアップ
============================
コンソールからの手入力を想定し、キーを1つ入力するたびに実際にAPIを
叩いて検証する。打ち間違いはその場で検出され、再入力を求められる。
使い方: venv/bin/python setup_keys.py
"""
import os
import sys

ENV_PATH = ".env"


def read_env() -> dict:
    env = {}
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k] = v
    return env


def write_env(env: dict):
    with open(ENV_PATH, "w", encoding="utf-8") as f:
        f.write("# cryptobot APIキー(setup_keys.pyで生成)\n")
        for k in ("BITFLYER_API_KEY", "BITFLYER_API_SECRET",
                  "ANTHROPIC_API_KEY", "DISCORD_WEBHOOK_URL"):
            f.write(f"{k}={env.get(k, '')}\n")
    os.chmod(ENV_PATH, 0o600)


def ask(prompt: str, current: str) -> str:
    hint = f"(現在: 設定済み・空エンターで維持)" if current else "(未設定)"
    val = input(f"{prompt} {hint}\n> ").strip()
    return val if val else current


def verify_bitflyer(key: str, secret: str) -> bool:
    os.environ["BITFLYER_API_KEY"] = key
    os.environ["BITFLYER_API_SECRET"] = secret
    try:
        from bitflyer_client import BitflyerClient
        bal = BitflyerClient().balance()
        jpy = bal.get("JPY", 0)
        print(f"  ✓ bitFlyer認証OK (JPY残高: {jpy:,.0f}円)")
        return True
    except Exception as e:
        print(f"  ✗ bitFlyer認証失敗: {e}")
        return False


def verify_anthropic(key: str) -> bool:
    os.environ["ANTHROPIC_API_KEY"] = key
    try:
        import anthropic
        client = anthropic.Anthropic()
        r = client.messages.create(model="claude-haiku-4-5",
                                   max_tokens=10,
                                   messages=[{"role": "user",
                                              "content": "OKとだけ返して"}])
        print(f"  ✓ Anthropic認証OK ({r.content[0].text.strip()[:10]})")
        return True
    except Exception as e:
        print(f"  ✗ Anthropic認証失敗: {e}")
        return False


def verify_discord(url: str) -> bool:
    if not url:
        print("  - Discord未設定(通知はコンソール出力のみ。後で追加可)")
        return True
    try:
        import requests
        r = requests.post(url, json={"content": "✅ cryptobot接続テスト"},
                          timeout=10)
        if r.status_code in (200, 204):
            print("  ✓ Discord送信OK(チャンネルを確認して)")
            return True
        print(f"  ✗ Discord応答異常: {r.status_code}")
        return False
    except Exception as e:
        print(f"  ✗ Discord送信失敗: {e}")
        return False


def main():
    print("═══ cryptobot APIキー設定 ═══")
    print("キーを貼り付け/入力してエンター。1つずつ実際に検証します。\n")
    env = read_env()

    # bitFlyer(キーとシークレットのペアで検証)
    while True:
        env["BITFLYER_API_KEY"] = ask("① bitFlyer API Key",
                                      env.get("BITFLYER_API_KEY", ""))
        env["BITFLYER_API_SECRET"] = ask("② bitFlyer API Secret",
                                         env.get("BITFLYER_API_SECRET", ""))
        if verify_bitflyer(env["BITFLYER_API_KEY"],
                           env["BITFLYER_API_SECRET"]):
            break
        print("  → もう一度入力してください\n")

    while True:
        env["ANTHROPIC_API_KEY"] = ask("③ Anthropic APIキー (sk-ant-...)",
                                       env.get("ANTHROPIC_API_KEY", ""))
        if verify_anthropic(env["ANTHROPIC_API_KEY"]):
            break
        print("  → もう一度入力してください\n")

    while True:
        env["DISCORD_WEBHOOK_URL"] = ask("④ Discord Webhook URL(任意・空でスキップ)",
                                         env.get("DISCORD_WEBHOOK_URL", ""))
        if verify_discord(env["DISCORD_WEBHOOK_URL"]):
            break
        print("  → もう一度入力してください\n")

    write_env(env)
    print("\n═══ 全キー検証済み。.envに保存しました ═══")


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    main()
