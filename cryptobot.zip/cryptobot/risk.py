# -*- coding: utf-8 -*-
"""リスク管理(すべての取引の前に必ず通る関所)— 24時間市場版"""
import os
from datetime import datetime, time as dtime, timedelta
from zoneinfo import ZoneInfo

import config
import db

JST = ZoneInfo("Asia/Tokyo")


def is_halted() -> bool:
    return os.path.exists(config.HALT_FLAG)


def halt(reason: str):
    os.makedirs(os.path.dirname(config.HALT_FLAG), exist_ok=True)
    with open(config.HALT_FLAG, "w", encoding="utf-8") as f:
        f.write(f"{datetime.now(JST).isoformat()}\n{reason}\n")


def week_start(date_str: str) -> str:
    d = datetime.strptime(date_str, "%Y-%m-%d")
    return (d - timedelta(days=d.weekday())).strftime("%Y-%m-%d")


def _parse_hm(s: str) -> dtime:
    h, m = map(int, s.split(":"))
    return dtime(h, m)


def in_maintenance(now: datetime | None = None) -> bool:
    """bitFlyerの日次メンテナンス帯(前後に余裕込み)か"""
    t = (now or datetime.now(JST)).time()
    return _parse_hm(config.MAINTENANCE_START) <= t <= _parse_hm(config.MAINTENANCE_END)


def can_open_new(now: datetime | None = None) -> tuple[bool, str]:
    """新規エントリー可否。(可否, 理由)"""
    now = now or datetime.now(JST)
    today = db.today_jst()

    if is_halted():
        return False, "HALTフラグあり(手動解除待ち)"

    # 週次損失リミット(先に評価: 1日で週次まで割った場合もHALTさせる)
    wpl = db.pl_since(week_start(today))
    if wpl <= config.WEEKLY_LOSS_LIMIT_JPY:
        halt(f"週次損失リミット到達 ({wpl:.0f}円)")
        return False, f"週次損失リミット到達 ({wpl:.0f}円) → 全停止"

    # 日次損失リミット
    if db.daily_pl(today) <= config.DAILY_LOSS_LIMIT_JPY:
        return False, f"日次損失リミット到達 ({db.daily_pl(today):.0f}円)"

    # ポジション数
    if db.load_position() is not None:
        return False, "既にポジション保有中(最大1)"

    # メンテナンス時間帯
    if in_maintenance(now):
        return False, "取引所メンテナンス時間帯"

    return True, "OK"


def in_caution_window(plan: dict, now: datetime | None = None) -> bool:
    """重要イベント前後などの警戒時間帯か(朝の作戦で指定)"""
    now = now or datetime.now(JST)
    t = now.time()
    for win in plan.get("caution_windows", []):
        try:
            s = _parse_hm(win[0])
            e = _parse_hm(win[1])
            if s <= t <= e:
                return True
        except Exception:
            continue
    return False
