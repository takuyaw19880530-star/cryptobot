# -*- coding: utf-8 -*-
"""
cryptobot エントリポイント
==========================
使い方:
  python main.py morning   # 朝の作戦会議(cronで毎日7:00)
  python main.py run       # 執行エンジン(systemdで常時稼働)
  python main.py journal   # 日誌(cronで毎日0:05 = 前日分)
  python main.py review    # 週次反省会(cronで月曜8:00 = 前週分)
  python main.py backtest [日数]  # バックテスト(口座不要)
  python main.py status    # 現在の状態確認(手動)
  python main.py resume    # HALTフラグ解除(手動)
"""
import os
import sys

from dotenv import load_dotenv

load_dotenv()

import config  # noqa: E402
import db      # noqa: E402


def status():
    import risk
    from bitflyer_client import BitflyerClient
    bf = BitflyerClient()
    today = db.today_jst()
    plan = db.load_plan() or {}
    pos = db.load_position()
    print(f"日付           : {today}")
    print(f"DRY_RUN        : {config.DRY_RUN}")
    print(f"HALT           : {risk.is_halted()}")
    try:
        tick = bf.ticker(config.PRODUCT_CODE)
        print(f"BTC/JPY        : {tick['mid']:,.0f} "
              f"(bitFlyer稼働: {bf.health(config.PRODUCT_CODE)})")
    except Exception as e:
        print(f"BTC/JPY        : 取得失敗 ({e})")
    print(f"レジーム       : {plan.get('regime', '未判定')}")
    print(f"ポジション     : {pos or 'なし'}")
    print(f"本日損益       : {db.daily_pl(today):+.0f}円")
    print(f"今週損益       : {db.pl_since(risk.week_start(today)):+.0f}円")


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "morning":
        from regime import run_morning_briefing
        run_morning_briefing()
    elif cmd == "run":
        from executor import loop
        loop()
    elif cmd == "journal":
        from journal import write_journal
        write_journal()
    elif cmd == "review":
        from journal import weekly_review
        weekly_review()
    elif cmd == "backtest":
        import backtest
        days = int(sys.argv[2]) if len(sys.argv) > 2 else 90
        history = backtest.fetch_history(days)
        result = backtest.run_backtest(history)
        backtest.print_report(result)
        backtest.save_csv(result["trades"])
    elif cmd == "status":
        status()
    elif cmd == "resume":
        if os.path.exists(config.HALT_FLAG):
            os.remove(config.HALT_FLAG)
            print("HALTフラグを解除しました")
        else:
            print("HALTフラグはありません")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
