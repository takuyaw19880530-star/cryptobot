# -*- coding: utf-8 -*-
"""
市場データクライアント(bitbank Public API)
===========================================
bitFlyerの公式APIにはローソク足エンドポイントがないため、
チャートデータは口座不要のbitbank Public APIから取得する。
取引所間のBTC価格差は僅少で、レジーム判定・バックテスト用途には十分。

エンドポイント(実弾移行前に公式ドキュメントで再確認):
  GET https://public.bitbank.cc/{pair}/candlestick/{type}/{YYYYMMDD}
  type: 1min/5min/15min/30min/1hour は YYYYMMDD、日足以上は YYYY
  応答: {"success":1,"data":{"candlestick":[{"ohlcv":[[o,h,l,c,vol,ts_ms],...]}]}}
  ※ 数値は文字列で返る。日付グルーピングはUTC基準の可能性があるため、
    呼び出し側は前後の日付も取得してタイムスタンプでフィルタすること。
"""
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import requests

import config

JST = ZoneInfo("Asia/Tokyo")
BITBANK_URL = "https://public.bitbank.cc"


def candles(interval: str, date: str) -> list[dict]:
    """指定日のローソク足。[{'openTime': ms, 'open','high','low','close'}]"""
    url = f"{BITBANK_URL}/{config.BITBANK_PAIR}/candlestick/{interval}/{date}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    res = r.json()
    if res.get("success") != 1:
        raise RuntimeError(f"bitbank API error: {res}")
    out = []
    for block in res["data"]["candlestick"]:
        for o, h, l, c, _vol, ts in block["ohlcv"]:
            out.append({"openTime": int(ts), "open": float(o),
                        "high": float(h), "low": float(l),
                        "close": float(c)})
    out.sort(key=lambda k: k["openTime"])
    return out


def recent_candles(interval: str = "15min", days: int = 2) -> list[dict]:
    """直近days日分を(UTC/JSTの日付ズレを吸収するため広めに)取得して結合"""
    now = datetime.now(JST)
    out = []
    for d in range(days, -1, -1):
        date = (now - timedelta(days=d)).strftime("%Y%m%d")
        try:
            out += candles(interval, date)
        except Exception:
            pass
        time.sleep(0.2)
    # 重複除去(日付境界の重なり対策)
    seen, uniq = set(), []
    for k in out:
        if k["openTime"] not in seen:
            seen.add(k["openTime"])
            uniq.append(k)
    return uniq
