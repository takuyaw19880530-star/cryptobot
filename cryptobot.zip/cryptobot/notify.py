# -*- coding: utf-8 -*-
"""Discord Webhook通知(未設定ならコンソール出力のみ)"""
import os

import requests


def send(message: str):
    print(message)
    url = os.environ.get("DISCORD_WEBHOOK_URL", "")
    if not url:
        return
    try:
        requests.post(url, json={"content": message[:1900]}, timeout=10)
    except Exception as e:
        print(f"[notify] Discord送信失敗: {e}")
