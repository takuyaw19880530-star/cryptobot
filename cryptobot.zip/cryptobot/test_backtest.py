# -*- coding: utf-8 -*-
"""cryptobotバックテストエンジンの決定論的検証(合成データ)。実データ不要"""
import math
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import backtest
import config
from backtest import classify_regime, run_backtest
from executor import calc_size
from indicators import ema
from strategy import entry_signal, exit_signal, pl_of

JST = ZoneInfo("Asia/Tokyo")
P0 = 15_000_000.0  # BTC価格の基準(1,500万円)


def mk_bars(date_str, prices, start_hour=0):
    base = datetime.strptime(date_str, "%Y%m%d").replace(
        hour=start_hour, tzinfo=JST)
    out = []
    for i, (o, h, l, c) in enumerate(prices):
        ts = base + timedelta(minutes=15 * i)
        out.append({"openTime": int(ts.timestamp() * 1000),
                    "open": o, "high": h, "low": l, "close": c})
    return out


def flatbar(p, spread=0.0):
    return (p, p + spread, p - spread, p)


def main():
    # ═══ 1. classify_regime(%ベース) ═══
    up = [flatbar(P0 * (1 + 0.0003 * i), P0 * 0.0001) for i in range(96)]
    assert classify_regime(mk_bars("20260616", up)) == "trend_up"
    down = [flatbar(P0 * (1 - 0.0003 * i), P0 * 0.0001) for i in range(96)]
    assert classify_regime(mk_bars("20260616", down)) == "trend_down"
    sine = [flatbar(P0 * (1 + 0.003 * math.sin(i / 4)), P0 * 0.0001)
            for i in range(96)]
    assert classify_regime(mk_bars("20260616", sine)) == "range"
    assert classify_regime([]) == "no_trade"
    print("OK 1. レジーム代理判定(%ベース)")

    # ═══ 2. entry_signal(ロングオンリー) ═══
    closes = [P0 * (1 + 0.0002 * i + 0.0006 * math.sin(i / 3))
              for i in range(95)]
    closes += [closes[-1] * (1 - 0.0004 * (i + 1)) for i in range(5)]  # 押し目
    e20_val = ema(closes, 20)[-1]
    sig = entry_signal("trend_up", closes, ask=e20_val, bid=e20_val * 0.9999)
    assert sig and sig["side"] == "BUY", sig
    # SL/TP幅が%設定どおりか
    assert math.isclose((sig["entry"] - sig["sl"]) / sig["entry"] * 100,
                        config.TREND_SL_PCT, rel_tol=1e-6)
    assert math.isclose((sig["tp"] - sig["entry"]) / sig["entry"] * 100,
                        config.TREND_TP_PCT, rel_tol=1e-6)
    # 急落でBB下限+RSI低 → レンジ逆張り買い
    closes_r = [P0 * (1 + (0.0003 if i % 2 else -0.0003)) for i in range(70)]
    closes_r += [closes_r[-1] * (1 - 0.0008 * (i + 1)) for i in range(10)]
    sig_r = entry_signal("range", closes_r, ask=closes_r[-1],
                         bid=closes_r[-1] * 0.9999)
    assert sig_r and sig_r["side"] == "BUY", sig_r
    # ロングオンリー: trend_down / no_trade は必ずNone
    assert entry_signal("trend_down", closes, P0, P0) is None
    assert entry_signal("no_trade", closes, P0, P0) is None
    assert entry_signal("range", closes[:10], P0, P0) is None
    print("OK 2. entry_signal(買いのみ/trend_downは常に見送り)")

    # ═══ 3. exit_signal と pl_of ═══
    pos = {"side": "BUY", "entry": P0, "size": 0.00133,
           "sl": P0 * 0.988, "tp": P0 * 1.018}
    assert exit_signal(pos, bid=P0 * 0.9879, ask=P0 * 0.988)["reason"].startswith("損切り")
    assert exit_signal(pos, bid=P0 * 1.0181, ask=P0 * 1.0182)["reason"].startswith("利確")
    assert exit_signal(pos, bid=P0, ask=P0 * 1.0001) is None
    pct, jpy = pl_of(pos, P0 * 1.018)
    assert math.isclose(pct, 1.8, abs_tol=0.01), pct
    assert math.isclose(jpy, P0 * 0.018 * 0.00133, abs_tol=1), jpy
    print(f"OK 3. exit_signal/pl_of (TP+1.8% = {jpy:+.0f}円)")

    # ═══ 4. サイジング ═══
    assert calc_size(15_000_000) == round(config.ORDER_JPY / 15_000_000, 8)
    # 最小ロット(0.001BTC)が投入上限を超える高値 → 見送り
    assert calc_size(config.MAX_ORDER_JPY / config.MIN_BTC_SIZE + 1) is None
    # ORDER_JPYが最小ロット未満の価格帯 → 最小ロットに切り上げ
    assert calc_size(25_000_000) == config.MIN_BTC_SIZE  # 2万円分<0.001BTC
    print("OK 4. サイジング(通常/上限超え見送り/最小ロット切上げ)")

    # ═══ 5. エンジンメカニクス(スタブで決定論化) ═══
    def stub_buy(regime, closes, ask, bid):
        return {"side": "BUY", "entry": ask, "sl": ask * 0.988,
                "tp": ask * 1.018, "reason": "stub"}

    orig = backtest.entry_signal
    backtest.entry_signal = stub_buy
    day0 = mk_bars("20260615", up)

    # 5a. 同一足でSL/TP両到達 → SL優先
    d1 = [flatbar(P0), (P0, P0 * 1.02, P0 * 0.985, P0)] + [flatbar(P0)] * 20
    r = run_backtest([("20260615", day0), ("20260616", mk_bars("20260616", d1))])
    assert r["n"] >= 1 and r["trades"][0]["reason_close"] == "損切り"
    assert r["trades"][0]["pl_jpy"] < 0
    print("OK 5a. 同一足SL/TP両到達 → SL優先")

    # 5b. 日次リミットで当日停止(連続下落日)
    fall = [flatbar(P0 * (1 - 0.013) ** i) for i in range(96)]
    r = run_backtest([("20260615", day0), ("20260616", mk_bars("20260616", fall))])
    assert r["total_jpy"] <= config.DAILY_LOSS_LIMIT_JPY, r["total_jpy"]
    assert r["total_jpy"] > config.DAILY_LOSS_LIMIT_JPY - 350, r["total_jpy"]
    print(f"OK 5b. 日次リミット近傍で停止 ({r['total_jpy']:+.0f}円, {r['n']}敗)")

    # 5c. trend_down / no_trade の日はトレードゼロ
    backtest.entry_signal = orig
    r = run_backtest([("20260615", mk_bars("20260615", down)),
                      ("20260616", mk_bars("20260616", down))])
    assert r["n"] == 0 and r["regime_days"].get("trend_down") == 1
    print("OK 5c. 下降トレンド日は取引ゼロ(ロングオンリー)")

    # 5d. エッジ: 空データ/1日のみ
    assert run_backtest([])["n"] == 0
    assert run_backtest([("20260616", mk_bars("20260616", up))])["n"] == 0
    print("OK 5d. 空データ/初日のみ → 安全にゼロ")

    # ═══ 6. リアリスティック統合: ランダムウォーク30日 ═══
    import random
    random.seed(7)
    backtest.entry_signal = orig
    days, price = [], P0
    d = datetime(2026, 5, 4, tzinfo=JST)
    for _ in range(30):
        drift = random.uniform(-0.0002, 0.0002)
        bars = []
        for _ in range(96):
            o = price
            price *= 1 + drift + random.gauss(0, 0.0012)
            h = max(o, price) * 1.0003
            l = min(o, price) * 0.9997
            bars.append((o, h, l, price))
        days.append((d.strftime("%Y%m%d"), mk_bars(d.strftime("%Y%m%d"), bars)))
        d += timedelta(days=1)
    r = run_backtest(days)
    for t in r["trades"]:
        assert t["side"] == "BUY"                      # ロングオンリー
        sl_pct = (t["entry"] - t["sl"]) / t["entry"] * 100
        assert any(math.isclose(sl_pct, x, abs_tol=1e-6)
                   for x in (config.TREND_SL_PCT, config.RANGE_SL_PCT)), t
    print(f"OK 6. 統合30日: {r['n']}トレード 勝率{r['win_rate']}% "
          f"合計{r['total_jpy']:+.0f}円 レジーム{r['regime_days']}")

    print("\n═══ 全テスト通過 ═══")


if __name__ == "__main__":
    main()
