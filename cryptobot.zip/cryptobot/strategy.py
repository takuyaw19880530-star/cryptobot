# -*- coding: utf-8 -*-
"""
執行戦略(BTC/JPY現物・ロングオンリー・%ベース)
================================================
- trend_up: EMA20への押し目買い
- range   : ボリンジャーバンド下限タッチ + RSIフィルターで逆張り買い
- trend_down / no_trade: 見送り(現物のため空売り不可)

FX版と同じく、entry_signal/exit_signal は純粋関数で
ライブ(executor)とバックテスト(backtest)が同一実装を共有する。
"""
import config
from indicators import bollinger, ema, rsi


# ═══════════════ 純粋関数(戦略の本体) ═══════════════

def entry_signal(regime: str, closes: list[float],
                 ask: float, bid: float) -> dict | None:
    """
    エントリー判定(買いのみ)。closes: 15分足終値(古い→新しい、60本以上)
    戻り値: {'side','entry','sl','tp','reason'} または None
    """
    if regime not in ("trend_up", "range") or len(closes) < 60:
        return None

    price = (ask + bid) / 2
    r = rsi(closes)
    if r is None:
        return None

    if regime == "trend_up":
        e20 = ema(closes, 20)
        e50 = ema(closes, 50)
        if not e20 or not e50 or e20[-1] <= e50[-1]:
            return None
        # 押し目: 価格がEMA20近傍(±EMA_NEAR_PCT%)、かつRSI非過熱
        near = e20[-1] * config.EMA_NEAR_PCT / 100
        if abs(price - e20[-1]) <= near and r < 65:
            sl = ask * (1 - config.TREND_SL_PCT / 100)
            tp = ask * (1 + config.TREND_TP_PCT / 100)
            return {"side": "BUY", "entry": ask, "sl": sl, "tp": tp,
                    "reason": f"上昇トレンド押し目 (EMA20={e20[-1]:,.0f}, RSI={r:.0f})"}

    elif regime == "range":
        bb = bollinger(closes)
        if not bb:
            return None
        if price <= bb["lower"] and r < config.RSI_OVERSOLD:
            sl = ask * (1 - config.RANGE_SL_PCT / 100)
            tp = ask * (1 + config.RANGE_TP_PCT / 100)
            return {"side": "BUY", "entry": ask, "sl": sl, "tp": tp,
                    "reason": f"レンジ下限逆張り買い (BB下限={bb['lower']:,.0f}, RSI={r:.0f})"}

    return None


def exit_signal(pos: dict, bid: float, ask: float) -> dict | None:
    """SL/TP到達判定。買い建玉の決済はbid"""
    if bid <= pos["sl"]:
        return {"exit": bid, "reason": "損切り(SL到達)"}
    if bid >= pos["tp"]:
        return {"exit": bid, "reason": "利確(TP到達)"}
    return None


def pl_of(pos: dict, exit_price: float) -> tuple[float, float]:
    """(pl_pct, pl_jpy) を返す。sizeはBTC数量"""
    diff = exit_price - pos["entry"]
    pct = diff / pos["entry"] * 100
    return round(pct, 2), round(diff * pos["size"], 0)


# ═══════════════ ライブ用ラッパー ═══════════════

def check_entry(plan: dict, bf) -> dict | None:
    import market_data
    k15 = market_data.recent_candles("15min", days=2)
    closes = [k["close"] for k in k15][-400:]
    tick = bf.ticker(config.PRODUCT_CODE)
    return entry_signal(plan.get("regime", "no_trade"), closes,
                        tick["ask"], tick["bid"])


def check_exit(pos: dict, bf) -> dict | None:
    tick = bf.ticker(config.PRODUCT_CODE)
    return exit_signal(pos, tick["bid"], tick["ask"])
